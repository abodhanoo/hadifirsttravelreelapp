import React, { useState } from 'react';
import { Alert, FlatList, Image, Pressable, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Button, Dot, Postcard } from '../ui';
import { colors, MAX_PHOTOS, MIN_PHOTOS } from '../config';
import { T } from '../fonts';
import { checkServer } from '../api';

type Props = {
  assets: ImagePicker.ImagePickerAsset[];
  setAssets: (a: ImagePicker.ImagePickerAsset[]) => void;
  serverUrl: string;
  setServerUrl: (u: string) => void;
  onNext: () => void;
  onSample: () => void;
};

export default function PickScreen({ assets, setAssets, serverUrl, setServerUrl, onNext, onSample }: Props) {
  const { width, height } = useWindowDimensions();
  const [showSettings, setShowSettings] = useState(false);
  const [serverStatus, setServerStatus] = useState<'unknown' | 'ok' | 'down' | 'checking'>('unknown');
  const contentW = width - 44;
  const tile = (contentW - 16) / 3;
  const remaining = MAX_PHOTOS - assets.length;

  const addAssets = (picked: ImagePicker.ImagePickerAsset[]) => setAssets([...assets, ...picked].slice(0, MAX_PHOTOS));

  const choose = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsMultipleSelection: true,
      orderedSelection: true,
      selectionLimit: Math.max(1, remaining),
      exif: true,
      quality: 1,
    });
    if (!res.canceled) addAssets(res.assets);
  };

  const capture = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) return Alert.alert('Camera access is off', 'Turn on camera access in Settings to take photos.');
    const res = await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], exif: true, quality: 1 });
    if (!res.canceled) addAssets(res.assets);
  };

  const test = async () => {
    setServerStatus('checking');
    setServerStatus((await checkServer(serverUrl)) ? 'ok' : 'down');
  };

  const topBar = (
    <View style={s.top}>
      <View style={s.brand}>
        <Dot size={18} />
        <Text style={[T.display, { fontSize: 19, letterSpacing: -0.5 }]}>Travel Reels</Text>
      </View>
      <Pressable accessibilityRole="button" accessibilityLabel="Render server settings" onPress={() => setShowSettings(!showSettings)} style={s.gear} hitSlop={8}>
        <Text style={{ color: colors.white, fontSize: 17 }}>⚙︎</Text>
      </Pressable>
    </View>
  );

  const settings = showSettings && (
    <View style={s.settings}>
      <Text style={s.settingsTitle}>Render server</Text>
      <Text style={s.settingsHelp}>The address your computer prints when the server starts.</Text>
      <TextInput
        value={serverUrl}
        onChangeText={(t) => { setServerUrl(t.trim()); setServerStatus('unknown'); }}
        autoCapitalize="none"
        autoCorrect={false}
        keyboardType="url"
        placeholder="http://192.168.1.20:4000"
        placeholderTextColor={colors.inkMuted}
        style={s.input}
      />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Pressable onPress={test} style={s.testBtn}><Text style={s.testText}>{serverStatus === 'checking' ? 'Checking…' : 'Test connection'}</Text></Pressable>
        {serverStatus === 'ok' && <Text style={{ color: colors.ink, fontFamily: 'Medium' }}>Connected</Text>}
        {serverStatus === 'down' && <Text style={{ color: colors.chipMaroonInk, flex: 1, fontFamily: 'Medium' }}>Can’t reach it. Check the server is running and your phone is on the same Wi-Fi.</Text>}
      </View>
    </View>
  );

  // ---------- First screen: nothing picked yet ----------
  if (assets.length === 0) {
    const heroH = Math.max(250, Math.min(330, height * 0.37));
    const k = heroH / 330;
    const cw = 156 * k;
    return (
      <View style={{ flex: 1 }}>
        {topBar}
        {settings}
        <View style={{ height: heroH, marginTop: 6 }}>
          <View style={{ position: 'absolute', right: -30, top: 6, width: 210 * k, height: 210 * k, borderRadius: 105 * k, backgroundColor: 'rgba(255,255,255,0.16)' }} />
          <Postcard scene="event" label="AI Summit" width={cw} rotate="-9deg" style={{ left: 6, top: 46 * k }} />
          <Postcard scene="rooftop" label="Rooftop" width={cw} rotate="8deg" style={{ left: contentW - cw - 8, top: 70 * k }} />
          <Postcard scene="party" label="Launch party" width={cw} rotate="-1deg" style={{ left: contentW / 2 - cw / 2, top: 8 * k }} />
        </View>
        <Text style={[T.display, { fontSize: 46, lineHeight: 48, marginTop: 8 }]}>Your night,{'\n'}as a reel.</Text>
        <Text style={[T.body, { marginTop: 14, maxWidth: 320 }]}>
          Pick your photos. We name the place, add music and cut a 30-second reel for Instagram and Facebook.
        </Text>
        <View style={{ flex: 1 }} />
        <View style={{ gap: 12 }}>
          <Button title="Choose photos" onPress={choose} />
          <Button title="Take photos now" variant="outline" onPress={capture} />
          <Pressable onPress={onSample} accessibilityRole="button" style={{ alignSelf: 'center', paddingVertical: 6 }}>
            <Text style={[T.medium, { color: colors.textSoft }]}>Try it with sample photos</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  // ---------- Photos picked ----------
  const needMore = assets.length < MIN_PHOTOS;
  return (
    <View style={{ flex: 1 }}>
      {topBar}
      {settings}
      <Text style={[T.title, { marginTop: 18 }]}>Your photos</Text>
      <Text style={[T.body, { marginTop: 6, marginBottom: 14 }]}>
        {assets.length} of {MAX_PHOTOS}. They play in this order.
      </Text>
      <FlatList
        data={assets}
        keyExtractor={(a, i) => a.assetId ?? `${a.uri}-${i}`}
        numColumns={3}
        columnWrapperStyle={{ gap: 8 }}
        contentContainerStyle={{ gap: 8, paddingBottom: 16 }}
        style={{ flex: 1 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item, index }) => (
          <View style={[s.tile, { width: tile, height: tile * 1.3 }]}>
            <Image source={{ uri: item.uri }} style={{ flex: 1, borderRadius: 9 }} />
            <View style={s.badge}><Text style={s.badgeText}>{index + 1}</Text></View>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Remove photo ${index + 1}`}
              hitSlop={8}
              style={s.remove}
              onPress={() => setAssets(assets.filter((_, i) => i !== index))}
            >
              <Text style={{ color: colors.white, fontSize: 11 }}>✕</Text>
            </Pressable>
          </View>
        )}
      />
      <View style={{ gap: 10 }}>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Button title="Add from gallery" variant="soft" compact onPress={choose} disabled={remaining <= 0} style={{ flex: 1 }} />
          <Button title="Camera" variant="soft" compact onPress={capture} disabled={remaining <= 0} style={{ flex: 0.6 }} />
        </View>
        <Button
          title={needMore ? `Add ${MIN_PHOTOS - assets.length} more photo` : `Continue with ${assets.length} photos`}
          onPress={onNext}
          disabled={needMore}
        />
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  gear: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.glass, alignItems: 'center', justifyContent: 'center' },
  settings: { backgroundColor: colors.salt, borderRadius: 22, padding: 16, marginTop: 14, gap: 8 },
  settingsTitle: { fontFamily: 'Display', fontSize: 18, color: colors.ink, letterSpacing: -0.4 },
  settingsHelp: { fontFamily: 'Body', color: colors.inkMuted, fontSize: 13.5 },
  input: { backgroundColor: colors.white, color: colors.ink, borderRadius: 12, paddingHorizontal: 12, height: 46, borderWidth: 1, borderColor: colors.line, fontFamily: 'Medium' },
  testBtn: { backgroundColor: colors.maroon, borderRadius: 12, paddingHorizontal: 14, height: 40, justifyContent: 'center' },
  testText: { color: colors.white, fontFamily: 'Medium', fontSize: 14 },
  tile: { backgroundColor: colors.salt, borderRadius: 13, padding: 3 },
  badge: { position: 'absolute', left: 8, top: 8, minWidth: 22, height: 22, borderRadius: 11, backgroundColor: colors.ink, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  badgeText: { color: colors.white, fontFamily: 'Display', fontSize: 12 },
  remove: { position: 'absolute', right: 8, top: 8, width: 22, height: 22, borderRadius: 11, backgroundColor: 'rgba(10,27,61,0.75)', alignItems: 'center', justifyContent: 'center' },
});
