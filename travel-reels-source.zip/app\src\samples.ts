import { Asset } from 'expo-asset';
import type { ImagePickerAsset } from 'expo-image-picker';
import { photos, SAMPLE_ORDER } from './config';

/** Loads the bundled sample photos as local files, so the whole flow can be tried without picking any. */
export async function loadSamplePhotos(): Promise<ImagePickerAsset[]> {
  return Promise.all(
    SAMPLE_ORDER.map(async (name) => {
      const asset = Asset.fromModule(photos[name]);
      await asset.downloadAsync();
      return {
        uri: asset.localUri ?? asset.uri,
        width: asset.width ?? 1000,
        height: asset.height ?? 1000,
        fileName: `${name}.jpg`,
        mimeType: 'image/jpeg',
      } as ImagePickerAsset;
    })
  );
}
