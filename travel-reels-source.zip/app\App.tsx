import React, { useCallback, useRef, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, StyleSheet, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import type { ImagePickerAsset } from 'expo-image-picker';
import { colors, DEFAULT_SERVER_URL, Mood } from './src/config';
import { fontSources } from './src/fonts';
import { Backdrop, Segments } from './src/ui';
import { downloadVideo, getJob, startRender } from './src/api';
import { loadSamplePhotos } from './src/samples';
import PickScreen from './src/screens/PickScreen';
import DetailsScreen from './src/screens/DetailsScreen';
import RenderScreen from './src/screens/RenderScreen';
import PreviewScreen from './src/screens/PreviewScreen';

type Step = 'pick' | 'details' | 'render' | 'preview';
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export default function App() {
  const [fontsLoaded, fontError] = useFonts(fontSources);
  const [step, setStep] = useState<Step>('pick');
  const [serverUrl, setServerUrl] = useState(DEFAULT_SERVER_URL);
  const [assets, setAssets] = useState<ImagePickerAsset[]>([]);
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [mood, setMood] = useState<Mood | null>(null);

  const [stage, setStage] = useState('');
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [videoUri, setVideoUri] = useState<string | null>(null);
  const runId = useRef(0);

  const create = useCallback(async () => {
    if (!mood) return;
    const id = ++runId.current;
    const live = () => runId.current === id;
    setStep('render');
    setError(null);
    setProgress(0);
    setStage('Preparing photos');
    try {
      let job = await startRender({ serverUrl, assets, title: title.trim(), subtitle: subtitle.trim(), mood, onStage: (s) => live() && setStage(s) });
      if (!live()) return;
      setStage('Rendering on the server');
      while (job.status === 'queued' || job.status === 'rendering') {
        await sleep(1200);
        if (!live()) return;
        job = await getJob(serverUrl, job.id);
        setProgress(job.progress * 0.95);
      }
      if (job.status === 'error') throw new Error(job.error || 'Rendering failed');
      setStage('Downloading your reel');
      const uri = await downloadVideo(serverUrl, job);
      if (!live()) return;
      setProgress(1);
      setVideoUri(uri);
      setStep('preview');
    } catch (e: any) {
      if (!live()) return;
      const msg = String(e?.message ?? e);
      setError(/network request failed|failed to fetch/i.test(msg)
        ? `Couldn’t reach the render server at ${serverUrl}. Check that it’s running and your phone is on the same Wi-Fi, or change the address with the gear icon on the first screen.`
        : msg);
    }
  }, [serverUrl, assets, title, subtitle, mood]);

  const trySamples = async () => {
    try {
      setAssets(await loadSamplePhotos());
      setTitle('Friday night');
      setSubtitle('Karachi, Pakistan');
      setMood('party');
      setStep('details');
    } catch (e: any) {
      Alert.alert('Couldn’t load the sample photos', String(e?.message ?? e));
    }
  };

  const startOver = () => {
    runId.current++;
    setAssets([]); setTitle(''); setSubtitle(''); setMood(null); setVideoUri(null); setError(null);
    setStep('pick');
  };

  // Hold the first frame until the font is ready (or has failed, in which case the system font is used).
  if (!fontsLoaded && !fontError) return <View style={{ flex: 1, backgroundColor: colors.maroon }} />;

  const segment: 1 | 2 | 3 | 0 =
    step === 'pick' ? (assets.length > 0 ? 1 : 0) : step === 'details' ? 2 : step === 'render' ? 3 : 0;

  return (
    <SafeAreaProvider>
      <Backdrop>
        <SafeAreaView style={styles.root} edges={['top', 'bottom']}>
          <StatusBar style="light" />
          <KeyboardAvoidingView style={styles.body} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
            {segment > 0 && <Segments step={segment as 1 | 2 | 3} />}
            {step === 'pick' && (
              <PickScreen
                assets={assets}
                setAssets={setAssets}
                serverUrl={serverUrl}
                setServerUrl={setServerUrl}
                onNext={() => setStep('details')}
                onSample={trySamples}
              />
            )}
            {step === 'details' && (
              <DetailsScreen
                assets={assets}
                title={title} setTitle={setTitle}
                subtitle={subtitle} setSubtitle={setSubtitle}
                mood={mood} setMood={setMood}
                onBack={() => setStep('pick')}
                onCreate={create}
              />
            )}
            {step === 'render' && (
              <RenderScreen
                assets={assets}
                stage={stage}
                progress={progress}
                error={error}
                onRetry={create}
                onBack={() => { runId.current++; setStep('details'); }}
              />
            )}
            {step === 'preview' && videoUri && (
              <PreviewScreen uri={videoUri} title={title} onNewMusic={create} onStartOver={startOver} />
            )}
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Backdrop>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  body: { flex: 1, paddingHorizontal: 22, paddingTop: 14, paddingBottom: 14 },
});
