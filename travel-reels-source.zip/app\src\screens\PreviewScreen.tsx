import React, { useState } from 'react';
import { Alert, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useVideoPlayer, VideoView } from 'expo-video';
import * as MediaLibrary from 'expo-media-library';
import * as Sharing from 'expo-sharing';
import { Button } from '../ui';
import { colors } from '../config';
import { T } from '../fonts';

export default function PreviewScreen({ uri, title, onNewMusic, onStartOver }: {
  uri: string; title: string; onNewMusic: () => void; onStartOver: () => void;
}) {
  const { height } = useWindowDimensions();
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const player = useVideoPlayer(uri, (p) => { p.loop = true; p.play(); });

  const videoH = Math.min(height * 0.5, 480);
  const videoW = (videoH * 9) / 16;

  const save = async () => {
    setSaving(true);
    try {
      const perm = await MediaLibrary.requestPermissionsAsync(true);
      if (!perm.granted) {
        Alert.alert('Gallery access is off', 'Allow access to your gallery to save the reel.');
        return;
      }
      await MediaLibrary.saveToLibraryAsync(uri);
      setSaved(true);
    } catch (e: any) {
      Alert.alert('Couldn’t save the reel', e?.message ?? String(e));
    } finally {
      setSaving(false);
    }
  };

  const share = async () => {
    if (!(await Sharing.isAvailableAsync())) return Alert.alert('Sharing isn’t available on this device');
    // Opens the system share sheet. Pick Instagram (Reels) or Facebook there.
    await Sharing.shareAsync(uri, { mimeType: 'video/mp4', dialogTitle: `Share your ${title} reel`, UTI: 'public.mpeg-4' });
  };

  return (
    <View style={{ flex: 1 }}>
      <Text style={[T.title, { fontSize: 34 }]}>Ready to post</Text>
      <View style={{ alignItems: 'center', marginTop: 16 }}>
        <View style={{ width: videoW, height: videoH + 14, borderRadius: 28, backgroundColor: 'rgba(10,10,14,0.45)' }}>
          <View style={[s.frame, { width: videoW, height: videoH }]}>
            <VideoView player={player} style={{ width: '100%', height: '100%' }} contentFit="cover" nativeControls allowsFullscreen />
          </View>
        </View>
      </View>
      <View style={{ flex: 1 }} />
      <View style={{ gap: 10 }}>
        <Button title="Share to Instagram or Facebook" onPress={share} />
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Button title={saved ? 'Saved' : 'Save'} variant="outline" compact onPress={save} loading={saving} disabled={saved} style={{ flex: 1 }} />
          <Button title="New music" variant="outline" compact onPress={onNewMusic} style={{ flex: 1 }} />
        </View>
        <Button title="Make another reel" variant="soft" compact onPress={onStartOver} />
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  frame: { borderRadius: 26, borderWidth: 5, borderColor: colors.salt, overflow: 'hidden', backgroundColor: '#000' },
});
