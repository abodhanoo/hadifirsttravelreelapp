// Travel Reels render server — zero dependencies (Node 20+ and FFmpeg).
//   POST /render          multipart: photos[] (2–20 JPEG/PNG), title, subtitle?, mood
//   GET  /jobs/:id        → { status, progress, error?, videoUrl? }
//   GET  /jobs/:id/video  → the MP4
//   GET  /moods           → moods and how many tracks each has
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { Readable } from 'node:stream';
import { renderReel } from './render.js';

const PORT = Number(process.env.PORT || 4000);
const MUSIC_DIR = path.resolve(process.env.MUSIC_DIR || 'music');
const WORK_ROOT = fs.mkdtempSync(path.join(os.tmpdir(), 'travel-reels-'));
const MAX_PHOTOS = 20;
const MAX_BODY = 200 * 1024 * 1024;
const JOB_TTL_MS = 60 * 60 * 1000;

export const MOODS = ['party', 'event', 'mountain', 'sea', 'history', 'picnic', 'dinner'];
const jobs = new Map();
let busy = Promise.resolve(); // render one reel at a time

function tracksFor(mood) {
  const dir = path.join(MUSIC_DIR, mood);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter((f) => /\.(mp3|m4a|aac|wav|ogg)$/i.test(f)).map((f) => path.join(dir, f));
}

function pickTrack(mood) {
  const list = tracksFor(mood);
  return list.length ? list[crypto.randomInt(list.length)] : null;
}

function send(res, status, body, headers = {}) {
  res.writeHead(status, { 'content-type': 'application/json', 'access-control-allow-origin': '*', ...headers });
  res.end(JSON.stringify(body));
}

async function readForm(req) {
  const len = Number(req.headers['content-length'] || 0);
  if (len > MAX_BODY) throw Object.assign(new Error('Upload too large (max 200 MB)'), { status: 413 });
  const headers = new Headers();
  for (const [k, v] of Object.entries(req.headers)) if (typeof v === 'string') headers.set(k, v);
  const webReq = new Request(`http://localhost${req.url}`, {
    method: req.method, headers, body: Readable.toWeb(req), duplex: 'half',
  });
  return webReq.formData();
}

async function handleRender(req, res) {
  let form;
  try { form = await readForm(req); }
  catch (e) { return send(res, e.status || 400, { error: e.message || 'Expected multipart/form-data' }); }

  const files = form.getAll('photos').filter((f) => typeof f === 'object' && f.size > 0);
  const title = String(form.get('title') || '').trim().slice(0, 60);
  const subtitle = String(form.get('subtitle') || '').trim().slice(0, 60);
  const mood = MOODS.includes(String(form.get('mood'))) ? String(form.get('mood')) : 'party';

  if (files.length < 2) return send(res, 400, { error: 'Send at least 2 photos.' });
  if (files.length > MAX_PHOTOS) return send(res, 400, { error: `Send at most ${MAX_PHOTOS} photos.` });
  if (!title) return send(res, 400, { error: 'A location title is required.' });

  const id = crypto.randomUUID();
  const workDir = path.join(WORK_ROOT, id);
  fs.mkdirSync(workDir);
  const photos = [];
  for (const [i, f] of files.entries()) {
    const ext = /png/i.test(f.type) ? '.png' : '.jpg';
    const p = path.join(workDir, `photo_${String(i).padStart(2, '0')}${ext}`);
    fs.writeFileSync(p, Buffer.from(await f.arrayBuffer()));
    photos.push(p);
  }

  const music = pickTrack(mood);
  const job = { id, status: 'queued', progress: 0, createdAt: Date.now(), workDir, mood,
    music: music ? path.basename(music) : null, outPath: path.join(workDir, 'reel.mp4') };
  jobs.set(id, job);

  busy = busy.then(async () => {
    job.status = 'rendering';
    try {
      const { duration } = await renderReel({ photos, music, title, subtitle, outPath: job.outPath, workDir,
        onProgress: (p) => (job.progress = p) });
      Object.assign(job, { status: 'done', progress: 1, duration });
    } catch (e) {
      Object.assign(job, { status: 'error', error: e.message });
      console.error(`[job ${id}]`, e.message);
    }
  });

  send(res, 202, { id, status: job.status, music: job.music });
}

function publicJob(job) {
  const { id, status, progress, error, duration, music, mood } = job;
  return { id, status, progress: Math.round(progress * 100) / 100, error, duration, music, mood,
    videoUrl: status === 'done' ? `/jobs/${id}/video` : undefined };
}

function streamVideo(req, res, job) {
  const { size } = fs.statSync(job.outPath);
  const range = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
  const base = { 'content-type': 'video/mp4', 'accept-ranges': 'bytes', 'access-control-allow-origin': '*',
    'content-disposition': `inline; filename="reel-${job.id.slice(0, 8)}.mp4"` };
  if (range) {
    const start = range[1] ? Number(range[1]) : 0;
    const end = range[2] ? Math.min(Number(range[2]), size - 1) : size - 1;
    res.writeHead(206, { ...base, 'content-range': `bytes ${start}-${end}/${size}`, 'content-length': end - start + 1 });
    fs.createReadStream(job.outPath, { start, end }).pipe(res);
  } else {
    res.writeHead(200, { ...base, 'content-length': size });
    fs.createReadStream(job.outPath).pipe(res);
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (req.method === 'OPTIONS') {
      res.writeHead(204, { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,POST',
        'access-control-allow-headers': '*' });
      return res.end();
    }
    if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true });
    if (req.method === 'GET' && url.pathname === '/moods')
      return send(res, 200, MOODS.map((m) => ({ mood: m, tracks: tracksFor(m).length })));
    if (req.method === 'POST' && url.pathname === '/render') return handleRender(req, res);

    const m = /^\/jobs\/([\w-]+)(\/video)?$/.exec(url.pathname);
    if (req.method === 'GET' && m) {
      const job = jobs.get(m[1]);
      if (!job) return send(res, 404, { error: 'Job not found or expired.' });
      if (!m[2]) return send(res, 200, publicJob(job));
      if (job.status !== 'done') return send(res, 409, { error: 'Video not ready yet.' });
      return streamVideo(req, res, job);
    }
    send(res, 404, { error: 'Not found' });
  } catch (e) {
    console.error(e);
    if (!res.headersSent) send(res, 500, { error: 'Server error' });
  }
});

// Remove finished jobs after an hour.
setInterval(() => {
  for (const [id, job] of jobs) {
    if (Date.now() - job.createdAt > JOB_TTL_MS && job.status !== 'rendering') {
      fs.rmSync(job.workDir, { recursive: true, force: true });
      jobs.delete(id);
    }
  }
}, 5 * 60 * 1000).unref();

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Travel Reels server on http://0.0.0.0:${PORT}`);
  for (const m of MOODS) {
    const n = tracksFor(m).length;
    console.log(`  music/${m}: ${n} track(s)${n ? '' : '  ← add royalty-free tracks or run: npm run placeholder-music'}`);
  }
  const ips = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal);
  for (const i of ips) console.log(`  On your phone, use: http://${i.address}:${PORT}`);
});
