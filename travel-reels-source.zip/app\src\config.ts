// Address of the render server. On a phone, use your computer's LAN IP
// (the server prints it when it starts), e.g. http://192.168.1.20:4000,
// or the HTTPS address of a deployed server. You can also change it from the
// gear icon on the first screen.
export const DEFAULT_SERVER_URL = 'http://192.168.1.20:4000';

export const MIN_PHOTOS = 2;
export const MAX_PHOTOS = 20;

export type Mood = 'party' | 'event' | 'mountain' | 'sea' | 'history' | 'picnic' | 'dinner';

export const MOODS: { id: Mood; label: string; emoji: string }[] = [
  { id: 'party', label: 'Party', emoji: '🎉' },
  { id: 'event', label: 'Event', emoji: '🎤' },
  { id: 'mountain', label: 'Mountains', emoji: '🏔️' },
  { id: 'sea', label: 'Seaside', emoji: '🌊' },
  { id: 'history', label: 'History', emoji: '🏛️' },
  { id: 'picnic', label: 'Picnic', emoji: '🧺' },
  { id: 'dinner', label: 'Dinner', emoji: '🍽️' },
];

// Maroon and dark gray: deep wine red, graphite, and warm light grays.
export const colors = {
  ink: '#17181C',
  inkSoft: '#3D3F47',
  inkMuted: '#6A6C75',
  maroon: '#8A1529',
  maroonMid: '#5F0F1F',
  charcoal: '#1E1F24',
  notch: '#6B1122', // matches the background where the ticket notches sit
  accent: '#F4F1F1', // light-gray primary button
  accentShadow: '#B3A5A9',
  salt: '#F3F1F1', // paper gray used for cards
  line: '#D2CDCF',
  chip: '#E7E3E4',
  chipMaroon: '#F2D9DE',
  chipMaroonInk: '#6B1122',
  white: '#FFFFFF',
  glass: 'rgba(255,255,255,0.14)',
  glassLine: 'rgba(255,255,255,0.38)',
  textSoft: 'rgba(255,255,255,0.9)',
};

export const bgGradient = {
  colors: [colors.maroon, colors.maroonMid, colors.charcoal] as const,
  locations: [0, 0.5, 1] as const,
};

// Photos shown in the app. Replace the files in assets/photos with your own
// (keep the same names) to change them.
export const photos = {
  rooftop: require('../assets/photos/rooftop.jpg'),
  party: require('../assets/photos/party.jpg'),
  conference: require('../assets/photos/conference.jpg'),
  friends: require('../assets/photos/friends.jpg'),
  picnic: require('../assets/photos/picnic.jpg'),
  celebration: require('../assets/photos/celebration.jpg'),
  park: require('../assets/photos/park.jpg'),
  portrait: require('../assets/photos/portrait.jpg'),
} as const;
export type PhotoName = keyof typeof photos;

// Order used by "Try it with sample photos".
export const SAMPLE_ORDER: PhotoName[] = ['rooftop', 'party', 'conference', 'friends', 'picnic', 'celebration', 'park', 'portrait'];

// Portrait crops (1:1.3) used on the postcards of the first screen.
export const scenes = {
  party: require('../assets/photos/card-party.jpg'),
  event: require('../assets/photos/card-event.jpg'),
  rooftop: require('../assets/photos/card-rooftop.jpg'),
} as const;
export type SceneName = keyof typeof scenes;
