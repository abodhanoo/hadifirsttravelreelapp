import { StyleSheet } from 'react-native';
import * as BG from '@expo-google-fonts/bricolage-grotesque';

// Bricolage Grotesque: a characterful grotesque with tight, punchy display weights.
// Resolved by export name so the app still starts (with the system font) if a
// weight is missing from the installed version of the package.
const sources: Record<string, any> = {};
const add = (family: string, exportName: string) => {
  const font = (BG as any)[exportName];
  if (font) sources[family] = font;
};
add('Body', 'BricolageGrotesque_400Regular');
add('Medium', 'BricolageGrotesque_600SemiBold');
add('Display', 'BricolageGrotesque_800ExtraBold');

export const fontSources = sources;

export const T = StyleSheet.create({
  display: { fontFamily: 'Display', color: '#FFFFFF', letterSpacing: -1.6 },
  title: { fontFamily: 'Display', color: '#FFFFFF', fontSize: 32, lineHeight: 35, letterSpacing: -1.1 },
  h3: { fontFamily: 'Display', color: '#FFFFFF', fontSize: 19, letterSpacing: -0.4 },
  body: { fontFamily: 'Body', color: 'rgba(255,255,255,0.82)', fontSize: 15.5, lineHeight: 22 },
  medium: { fontFamily: 'Medium', color: '#FFFFFF', fontSize: 15 },
  button: { fontFamily: 'Display', fontSize: 17, letterSpacing: -0.2 },
});
