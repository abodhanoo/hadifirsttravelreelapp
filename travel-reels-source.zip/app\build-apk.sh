#!/usr/bin/env bash
# Builds the Travel Reels APK. Run from the app/ folder.
#   ./build-apk.sh          -> cloud build on Expo (free account, no Android SDK needed)
#   ./build-apk.sh local    -> build on this computer (needs JDK 17 + Android SDK)
set -euo pipefail
cd "$(dirname "$0")"
npm install
npx expo install --fix          # aligns package versions with the Expo SDK
if [ "${1:-}" = "local" ]; then
  npx expo prebuild --platform android --clean
  (cd android && ./gradlew assembleRelease)
  echo; echo "APK: $(pwd)/android/app/build/outputs/apk/release/app-release.apk"
else
  npx --yes eas-cli@latest login || true
  npx --yes eas-cli@latest build --platform android --profile apk
  echo; echo "Open the link above to download the APK."
fi
