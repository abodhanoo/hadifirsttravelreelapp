// Builds a 9:16 reel (1080x1920, 30fps) from photos with motion, transitions,
// a location title and background music, using FFmpeg.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

export const WIDTH = 1080;
export const HEIGHT = 1920;
export const FPS = 30;
const TRANSITION = 0.6; // seconds of overlap between photos
const TRANSITIONS = ['fade', 'slideleft', 'circleopen', 'smoothup', 'fadeblack', 'wipeleft', 'smoothleft', 'radial'];

const FONT_CANDIDATES = [
  process.env.FONT_PATH,
  path.resolve('fonts/Title.ttf'),
  '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
  '/System/Library/Fonts/Supplemental/Arial Bold.ttf',
  '/Library/Fonts/Arial Bold.ttf',
  'C:/Windows/Fonts/arialbd.ttf',
].filter(Boolean);

export function findFont() {
  const f = FONT_CANDIDATES.find((p) => fs.existsSync(p));
  if (!f) throw new Error('No title font found. Put a .ttf at server/fonts/Title.ttf or set FONT_PATH.');
  return f;
}

/** Total reel length: ~3s per photo, clamped to 20–30 seconds. */
export function planTiming(photoCount) {
  const total = Math.min(30, Math.max(20, photoCount * 3));
  const clip = (total + (photoCount - 1) * TRANSITION) / photoCount;
  const frames = Math.round(clip * FPS);
  const clipSec = frames / FPS;
  const actualTotal = photoCount * clipSec - (photoCount - 1) * TRANSITION;
  return { frames, clipSec, total: actualTotal };
}

/** Split a title into lines of roughly maxChars, without breaking words. */
function wrap(text, maxChars) {
  const words = text.trim().split(/\s+/);
  const lines = [];
  let line = '';
  for (const w of words) {
    if (line && (line + ' ' + w).length > maxChars) { lines.push(line); line = w; }
    else line = line ? line + ' ' + w : w;
  }
  if (line) lines.push(line);
  return lines.slice(0, 3);
}

// Escape a path for use inside an FFmpeg filter option value.
const esc = (p) => p.replace(/\\/g, '/').replace(/:/g, '\\:').replace(/'/g, "\\'");

function textLayers({ title, subtitle, total, workDir, font }) {
  const filters = [];
  let n = 0;
  const addText = (text, opts) => {
    const file = path.join(workDir, `text_${n++}.txt`);
    fs.writeFileSync(file, text, 'utf8');
    filters.push(
      `drawtext=fontfile='${esc(font)}':textfile='${esc(file)}':fontcolor=white:` +
      `borderw=${opts.border ?? 3}:bordercolor=black@0.55:shadowx=0:shadowy=4:shadowcolor=black@0.45:` +
      `fontsize=${opts.size}:x=${opts.x}:y=${opts.y}:alpha='${opts.alpha}'` +
      (opts.box ? `:box=1:boxcolor=black@0.38:boxborderw=22` : '')
    );
  };

  // Intro title: fades in at 0.5s, out by ~4.7s, centered in the lower third.
  const introAlpha = 'if(lt(t,0.5),0,if(lt(t,1.2),(t-0.5)/0.7,if(lt(t,4),1,if(lt(t,4.7),(4.7-t)/0.7,0))))';
  const lines = wrap(title, title.length > 28 ? 16 : 14);
  const size = lines.some((l) => l.length > 12) ? 84 : 100;
  const lineH = Math.round(size * 1.18);
  const blockTop = 1180 - (lines.length - 1) * lineH;
  lines.forEach((line, i) => {
    addText(line, { size, x: '(w-text_w)/2', y: blockTop + i * lineH, alpha: introAlpha, border: 4 });
  });
  if (subtitle) {
    addText(subtitle, { size: 46, x: '(w-text_w)/2', y: blockTop + lines.length * lineH + 18, alpha: introAlpha });
  }

  // Persistent location tag after the intro, fading out with the video.
  const tagAlpha = `if(lt(t,4.7),0,if(lt(t,5.3),(t-4.7)/0.6,if(gt(t,${(total - 1).toFixed(2)}),max(0,(${total.toFixed(2)}-t)),1)))`;
  const tag = title.length > 30 ? title.slice(0, 29) + '…' : title;
  addText(tag, { size: 44, x: 64, y: HEIGHT - 260, alpha: tagAlpha, box: true, border: 0 });
  return filters;
}

export function buildFilterGraph({ photoCount, frames, clipSec, total, title, subtitle, workDir, font }) {
  const parts = [];
  const CW = 1440, CH = 2560; // compose larger than output so zoompan stays smooth
  for (let i = 0; i < photoCount; i++) {
    const zoomIn = i % 2 === 0;
    const z = zoomIn ? `1+0.13*on/${frames}` : `1.13-0.13*on/${frames}`;
    // Alternate a gentle drift so consecutive shots don't feel identical.
    const drift = ['0', '0.5', '-0.5'][i % 3];
    const x = `(iw-iw/zoom)/2+(${drift})*(iw-iw/zoom)/2*on/${frames}`;
    parts.push(
      `[${i}:v]split=2[bgs${i}][fgs${i}]`,
      `[bgs${i}]scale=${CW}:${CH}:force_original_aspect_ratio=increase,crop=${CW}:${CH},boxblur=40:4,eq=brightness=-0.10:saturation=1.1[bg${i}]`,
      `[fgs${i}]scale=${CW}:${CH}:force_original_aspect_ratio=decrease[fg${i}]`,
      `[bg${i}][fg${i}]overlay=(W-w)/2:(H-h)/2,setsar=1,` +
        `zoompan=z='${z}':x='${x}':y='(ih-ih/zoom)/2':d=${frames}:s=${WIDTH}x${HEIGHT}:fps=${FPS},` +
        `format=yuv420p,setpts=PTS-STARTPTS[v${i}]`
    );
  }
  let last = 'v0';
  for (let i = 1; i < photoCount; i++) {
    const offset = (i * (clipSec - TRANSITION)).toFixed(3);
    const t = TRANSITIONS[(i - 1) % TRANSITIONS.length];
    const out = i === photoCount - 1 ? 'vjoined' : `x${i}`;
    parts.push(`[${last}][v${i}]xfade=transition=${t}:duration=${TRANSITION}:offset=${offset}[${out}]`);
    last = out;
  }
  if (photoCount === 1) parts.push(`[v0]null[vjoined]`);

  const texts = textLayers({ title, subtitle, total, workDir, font });
  parts.push(`[vjoined]${texts.join(',')},fade=t=in:st=0:d=0.4,fade=t=out:st=${(total - 0.6).toFixed(2)}:d=0.6[vout]`);
  return parts;
}

/**
 * Render a reel. Returns a promise; calls onProgress(0..1) while encoding.
 * @param {{photos: string[], music: string|null, title: string, subtitle?: string, outPath: string, workDir: string}} opts
 */
export function renderReel({ photos, music, title, subtitle, outPath, workDir, onProgress = () => {} }) {
  const { frames, clipSec, total } = planTiming(photos.length);
  const font = findFont();
  const graph = buildFilterGraph({ photoCount: photos.length, frames, clipSec, total, title, subtitle, workDir, font });

  const args = ['-y', '-hide_banner', '-loglevel', 'error', '-progress', 'pipe:1'];
  for (const p of photos) args.push('-i', p);

  const audioIdx = photos.length;
  if (music) args.push('-stream_loop', '-1', '-i', music);
  else args.push('-f', 'lavfi', '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100');
  graph.push(
    `[${audioIdx}:a]atrim=0:${total.toFixed(3)},asetpts=PTS-STARTPTS,volume=0.9,` +
    `afade=t=in:st=0:d=1,afade=t=out:st=${(total - 2).toFixed(2)}:d=2[aout]`
  );

  const scriptPath = path.join(workDir, 'filter.txt');
  fs.writeFileSync(scriptPath, graph.join(';\n'));
  args.push(
    '-filter_complex_script', scriptPath,
    '-map', '[vout]', '-map', '[aout]',
    '-c:v', 'libx264', '-preset', process.env.X264_PRESET || 'veryfast', '-crf', '20',
    '-profile:v', 'high', '-pix_fmt', 'yuv420p', '-r', String(FPS),
    '-c:a', 'aac', '-b:a', '192k', '-ar', '44100',
    '-t', total.toFixed(3), '-movflags', '+faststart', outPath
  );

  return new Promise((resolve, reject) => {
    const ff = spawn(process.env.FFMPEG_PATH || 'ffmpeg', args);
    let stderr = '';
    ff.stderr.on('data', (d) => (stderr += d));
    ff.stdout.on('data', (d) => {
      const m = /out_time_us=(\d+)/.exec(String(d));
      if (m) onProgress(Math.min(0.99, Number(m[1]) / 1e6 / total));
    });
    ff.on('error', (e) => reject(new Error(`Could not start FFmpeg: ${e.message}`)));
    ff.on('close', (code) => {
      if (code === 0) { onProgress(1); resolve({ duration: total }); }
      else reject(new Error(`FFmpeg failed (${code}): ${stderr.slice(-800)}`));
    });
  });
}
