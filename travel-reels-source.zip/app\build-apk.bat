@echo off
REM Builds the Travel Reels APK on Windows. Run from the app folder.
REM   build-apk.bat          -> cloud build on Expo (free account, no Android SDK needed)
REM   build-apk.bat local    -> build on this PC (needs JDK 17 + Android SDK)
cd /d "%~dp0"
call npm install || exit /b 1
call npx expo install --fix || exit /b 1
if /i "%1"=="local" (
  call npx expo prebuild --platform android --clean || exit /b 1
  cd android && call gradlew.bat assembleRelease || exit /b 1
  echo APK: %cd%\app\build\outputs\apk\release\app-release.apk
) else (
  call npx --yes eas-cli@latest login
  call npx --yes eas-cli@latest build --platform android --profile apk
  echo Open the link above to download the APK.
)
