import React from 'react';
import { ActivityIndicator, Pressable, StyleProp, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { bgGradient, colors, SceneName, scenes } from './config';
import { T } from './fonts';

/** Full-screen maroon-to-dark-gray backdrop that every screen sits on. */
export function Backdrop({ children }: { children: React.ReactNode }) {
  return (
    <LinearGradient colors={bgGradient.colors} locations={bgGradient.locations} start={{ x: 0.1, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ flex: 1 }}>
      {children}
    </LinearGradient>
  );
}

type ButtonProps = {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'outline' | 'soft';
  disabled?: boolean;
  loading?: boolean;
  compact?: boolean;
  style?: StyleProp<ViewStyle>;
};

export function Button({ title, onPress, variant = 'primary', disabled, loading, compact, style }: ButtonProps) {
  const primary = variant === 'primary';
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        s.btn,
        compact && s.compact,
        primary ? s.primary : variant === 'outline' ? s.outline : s.soft,
        primary && pressed && s.primaryPressed,
        !primary && pressed && { opacity: 0.8 },
        (disabled || loading) && s.disabled,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={primary ? colors.maroon : colors.white} />
      ) : (
        <Text style={[T.button, { color: primary ? colors.ink : colors.white }, compact && { fontSize: 15.5 }]} numberOfLines={1}>
          {title}
        </Text>
      )}
    </Pressable>
  );
}

/** Three-part progress bar: photos, place and mood, making the reel. */
export function Segments({ step }: { step: 1 | 2 | 3 }) {
  return (
    <View style={s.segs} accessibilityRole="progressbar" accessibilityLabel={`Step ${step} of 3`}>
      {[1, 2, 3].map((n) => (
        <View key={n} style={[s.seg, n <= step && { backgroundColor: colors.white }]} />
      ))}
    </View>
  );
}

/** A bundled illustration standing in for a photo. */
export function Scene({ name, style }: { name: SceneName; style?: StyleProp<ViewStyle> }) {
  return <Image source={scenes[name]} resizeMode="cover" style={style as any} />;
}

/** Paper postcard with a photo and a handwritten-style label. */
export function Postcard({ scene, label, width, rotate, style }: {
  scene: SceneName; label: string; width: number; rotate: string; style?: StyleProp<ViewStyle>;
}) {
  const pad = width * 0.06;
  return (
    <View
      style={[
        {
          position: 'absolute', width, height: width * 1.3, backgroundColor: colors.salt, borderRadius: width * 0.09,
          padding: pad, paddingBottom: width * 0.24, transform: [{ rotate }],
          shadowColor: '#050A32', shadowOpacity: 0.45, shadowRadius: 16, shadowOffset: { width: 0, height: 10 }, elevation: 10,
        },
        style,
      ]}
    >
      <Scene name={scene} style={{ flex: 1, borderRadius: width * 0.05 }} />
      <Text style={{ position: 'absolute', left: pad + 4, bottom: width * 0.07, fontFamily: 'Display', fontSize: width * 0.09, color: colors.ink, letterSpacing: -0.4 }}>
        {label}
      </Text>
    </View>
  );
}

export function Dot({ size, style }: { size: number; style?: StyleProp<ViewStyle> }) {
  return <View style={[{ width: size, height: size, borderRadius: size / 2, backgroundColor: colors.accent }, style]} />;
}

const s = StyleSheet.create({
  btn: { height: 58, borderRadius: 20, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18 },
  compact: { height: 52 },
  primary: { backgroundColor: colors.accent, borderBottomWidth: 6, borderBottomColor: colors.accentShadow },
  primaryPressed: { transform: [{ translateY: 3 }], borderBottomWidth: 3 },
  outline: { borderWidth: 2, borderColor: colors.glassLine },
  soft: { backgroundColor: colors.glass },
  disabled: { opacity: 0.5 },
  segs: { flexDirection: 'row', gap: 6, marginBottom: 20 },
  seg: { flex: 1, height: 5, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.22)' },
});
