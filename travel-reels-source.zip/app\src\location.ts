import * as Location from 'expo-location';
import * as MediaLibrary from 'expo-media-library';
import type { ImagePickerAsset } from 'expo-image-picker';
import type { Mood } from './config';

export type Coords = { latitude: number; longitude: number };
export type PlaceResult = {
  coords: Coords | null;
  source: 'photo' | 'gallery' | 'device' | 'none';
  title: string;
  subtitle: string;
  suggestedMood: Mood | null;
};

/** Convert EXIF GPS values (decimal, "deg/1,min/1,sec/100" or [d,m,s]) to decimal degrees. */
function toDecimal(value: unknown, ref?: unknown): number | null {
  let deg: number | null = null;
  if (typeof value === 'number') deg = value;
  else if (Array.isArray(value) && value.length >= 1) {
    const [d = 0, m = 0, s = 0] = value.map(Number);
    deg = d + m / 60 + s / 3600;
  } else if (typeof value === 'string') {
    const parts = value.split(',').map((p) => {
      const [n, dd] = p.split('/').map(Number);
      return dd ? n / dd : n;
    });
    if (parts.every((n) => !Number.isNaN(n))) {
      const [d = 0, m = 0, s = 0] = parts;
      deg = parts.length === 1 ? d : d + m / 60 + s / 3600;
    }
  }
  if (deg == null || Number.isNaN(deg)) return null;
  if (typeof ref === 'string' && /^[SW]/i.test(ref)) deg = -Math.abs(deg);
  return deg;
}

/** Read GPS from the photo's EXIF data (iOS stores it under "{GPS}", Android flat). */
export function gpsFromExif(exif: Record<string, any> | null | undefined): Coords | null {
  if (!exif) return null;
  const g = exif['{GPS}'];
  const lat = g ? toDecimal(g.Latitude, g.LatitudeRef) : toDecimal(exif.GPSLatitude, exif.GPSLatitudeRef);
  const lon = g ? toDecimal(g.Longitude, g.LongitudeRef) : toDecimal(exif.GPSLongitude, exif.GPSLongitudeRef);
  if (lat == null || lon == null || (lat === 0 && lon === 0)) return null;
  return { latitude: lat, longitude: lon };
}

async function gpsFromGallery(assetId: string): Promise<Coords | null> {
  try {
    const perm = await MediaLibrary.requestPermissionsAsync();
    if (!perm.granted) return null;
    const info = await MediaLibrary.getAssetInfoAsync(assetId);
    const loc = info.location;
    if (loc && (loc.latitude !== 0 || loc.longitude !== 0)) return { latitude: loc.latitude, longitude: loc.longitude };
  } catch {
    // Not available (e.g. limited access in Expo Go) — fall through.
  }
  return null;
}

export async function deviceLocation(): Promise<Coords | null> {
  const perm = await Location.requestForegroundPermissionsAsync();
  if (!perm.granted) return null;
  const last = await Location.getLastKnownPositionAsync({ maxAge: 10 * 60 * 1000 });
  const pos = last ?? (await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }));
  return { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
}

/** Pick the most useful name from a reverse-geocoded address. */
export async function describePlace(coords: Coords): Promise<{ title: string; subtitle: string; raw: string }> {
  try {
    await Location.requestForegroundPermissionsAsync();
    const [a] = await Location.reverseGeocodeAsync(coords);
    if (!a) return { title: '', subtitle: '', raw: '' };
    const looksLikeAddress = (s?: string | null) => !s || /^\d|\d{3,}|street|road|st\.|rd\./i.test(s);
    const candidates = [a.name, a.district, a.subregion, a.city, a.region].filter(
      (s): s is string => !!s && !looksLikeAddress(s)
    );
    const title = candidates[0] ?? a.city ?? a.region ?? a.country ?? '';
    const subtitle = [a.city, a.country].filter((s) => s && s !== title).join(', ');
    const raw = [a.name, a.street, a.district, a.city, a.subregion, a.region].filter(Boolean).join(' ');
    return { title, subtitle, raw };
  } catch {
    return { title: '', subtitle: '', raw: '' };
  }
}

const MOOD_KEYWORDS: [Mood, RegExp][] = [
  ['event', /summit|conference|convention|expo|hall|arena|auditorium|campus|hackathon|meetup|seminar|stadium|center|centre|institute|university|ai |tech/i],
  ['party', /party|club|lounge|nightclub|rooftop|terrace|bar |disco|festival|concert|beach club|farmhouse/i],
  ['sea', /beach|sea|ocean|coast|bay|harbou?r|port|marina|island|lagoon|creek|clifton|shore|seaview/i],
  ['mountain', /mount|mt\.?|peak|valley|hill|pass|glacier|lake|nathia|murree|naran|kaghan|hunza|swat|skardu|fairy|summit|alps/i],
  ['history', /fort|museum|tomb|mausoleum|mosque|masjid|temple|church|palace|ruin|heritage|monument|mazar|quaid|haveli|archae|old city|castle/i],
  ['dinner', /restaurant|hotel|grill|café|cafe|dining|club|banquet|marquee|lounge|bistro|kitchen/i],
  ['picnic', /park|garden|zoo|farm|resort|picnic|lawn|safari|bagh/i],
];

export function suggestMood(text: string): Mood | null {
  for (const [mood, re] of MOOD_KEYWORDS) if (re.test(text)) return mood;
  return null;
}

/**
 * Find where the photos were taken: photo EXIF → gallery metadata → this phone's location.
 * Uses the first photo that has a location.
 */
export async function detectPlace(assets: ImagePickerAsset[]): Promise<PlaceResult> {
  let coords: Coords | null = null;
  let source: PlaceResult['source'] = 'none';

  for (const a of assets) {
    coords = gpsFromExif(a.exif as Record<string, any> | undefined);
    if (coords) { source = 'photo'; break; }
  }
  if (!coords) {
    for (const a of assets.slice(0, 5)) {
      if (!a.assetId) continue;
      coords = await gpsFromGallery(a.assetId);
      if (coords) { source = 'gallery'; break; }
    }
  }
  if (!coords) {
    try { coords = await deviceLocation(); if (coords) source = 'device'; } catch { /* ignore */ }
  }
  if (!coords) return { coords: null, source: 'none', title: '', subtitle: '', suggestedMood: null };

  const place = await describePlace(coords);
  return { coords, source, title: place.title, subtitle: place.subtitle, suggestedMood: suggestMood(place.raw) };
}
