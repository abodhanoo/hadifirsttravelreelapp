// Generates simple synthesized placeholder tracks (one per mood) so the app
// works before you add real music. Replace them with licensed royalty-free
// tracks for anything you publish.
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const LEN = 40; // seconds per chord loop file
const N = (semitones) => 220 * Math.pow(2, semitones / 12); // A3-relative

// Each mood: chord progression (semitone offsets from A3), seconds per chord, pulse speed.
const MOODS = {
  party:    { chords: [[0, 3, 7, 12], [-2, 2, 5, 10], [3, 7, 10, 15], [-4, 0, 3, 8]], per: 1.5, pulse: 4 },
  event:    { chords: [[-9, -2, 3, 7], [-4, 0, 3, 7], [-7, 0, 5, 9], [-2, 2, 7, 10]], per: 3, pulse: 1.5 },
  mountain: { chords: [[-9, -5, -2, 3], [-4, 0, 3, 7], [-7, -3, 0, 5], [-2, 2, 5, 9]], per: 5, pulse: 0.5 },
  sea:      { chords: [[-9, -2, 3, 7], [-7, 0, 3, 8], [-4, 0, 5, 7], [-5, 2, 5, 10]], per: 4, pulse: 0.25 },
  history:  { chords: [[0, 3, 7, 12], [-4, 0, 3, 8], [-7, -4, 0, 5], [-5, -1, 2, 7]], per: 5, pulse: 0.33 },
  picnic:   { chords: [[3, 7, 10, 15], [-2, 2, 5, 10], [0, 3, 7, 12], [-4, 0, 5, 8]], per: 2, pulse: 2 },
  dinner:   { chords: [[-9, -5, -2, 2], [-4, -1, 3, 6], [-2, 2, 5, 9], [-7, -3, 0, 4]], per: 4, pulse: 1 },
};

for (const [mood, cfg] of Object.entries(MOODS)) {
  const dir = path.resolve('music', mood);
  fs.mkdirSync(dir, { recursive: true });
  const cycle = cfg.chords.length * cfg.per;
  // Build: for each chord, a sum of sines gated to its time slot within the cycle.
  const terms = cfg.chords.map((chord, idx) => {
    const gate = `between(mod(t,${cycle}),${idx * cfg.per},${(idx + 1) * cfg.per})`;
    const env = `min(1,(mod(t,${cycle})-${idx * cfg.per})*2)`; // soft attack
    const tones = chord.map((s) => `sin(2*PI*${N(s).toFixed(2)}*t)`).join('+');
    return `${gate}*${env}*(${tones})`;
  });
  const pulse = `(0.75+0.25*sin(2*PI*${cfg.pulse}*t))`;
  const expr = `0.07*${pulse}*(${terms.join('+')})`;
  const out = path.join(dir, `placeholder-${mood}.mp3`);
  const r = spawnSync('ffmpeg', ['-y', '-hide_banner', '-loglevel', 'error',
    '-f', 'lavfi', '-i', `aevalsrc='${expr}|${expr}':s=44100:d=${LEN}`,
    '-af', 'aecho=0.8:0.7:120|240:0.3|0.2,lowpass=f=3000,afade=t=in:d=1',
    '-c:a', 'libmp3lame', '-b:a', '160k', out], { stdio: 'inherit' });
  console.log(r.status === 0 ? `✓ ${path.relative(process.cwd(), out)}` : `✗ ${mood} failed`);
}
