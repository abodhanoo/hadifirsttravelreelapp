// Renders a sample reel through the HTTP API using generated test photos.
// Usage: start the server (npm start), then: npm run test-render [photoDir]
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawnSync } from 'node:child_process';

const SERVER = process.env.SERVER_URL || 'http://localhost:4000';
let dir = process.argv[2];

if (!dir) {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'reel-test-'));
  const sizes = ['1600x1200', '1080x1440', '2000x1125', '1200x1600', '1600x1067', '1440x1080'];
  sizes.forEach((s, i) => {
    const out = path.join(dir, `test_${i}.jpg`);
    spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'lavfi', '-i',
      `gradients=s=${s}:c0=0x${(0x2a6fdb + i * 0x13579b).toString(16).slice(-6)}:c1=0xf2c14e:x0=0:y0=0:x1=${s.split('x')[0]}:y1=${s.split('x')[1]}:seed=${i}`,
      '-vf', `drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='Photo ${i + 1}':fontsize=120:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2`,
      '-frames:v', '1', out]);
  });
  console.log('Generated test photos in', dir);
}

const form = new FormData();
for (const f of fs.readdirSync(dir).filter((f) => /\.(jpe?g|png)$/i.test(f)).sort()) {
  form.append('photos', new Blob([fs.readFileSync(path.join(dir, f))], { type: 'image/jpeg' }), f);
}
form.append('title', process.env.TITLE || 'Clifton Beach');
form.append('subtitle', process.env.SUBTITLE ?? 'Karachi, Pakistan');
form.append('mood', process.env.MOOD || 'sea');

const start = Date.now();
const r = await fetch(`${SERVER}/render`, { method: 'POST', body: form });
const { id, error } = await r.json();
if (!id) throw new Error(error);
let job;
do {
  await new Promise((res) => setTimeout(res, 1000));
  job = await (await fetch(`${SERVER}/jobs/${id}`)).json();
  process.stdout.write(`\r${job.status} ${Math.round(job.progress * 100)}%   `);
} while (job.status === 'queued' || job.status === 'rendering');
console.log();
if (job.status !== 'done') throw new Error(job.error);
const buf = Buffer.from(await (await fetch(SERVER + job.videoUrl)).arrayBuffer());
fs.writeFileSync('test-reel.mp4', buf);
console.log(`Saved test-reel.mp4 (${(buf.length / 1e6).toFixed(1)} MB, ${job.duration.toFixed(1)}s, music: ${job.music}) in ${((Date.now() - start) / 1000).toFixed(1)}s`);
