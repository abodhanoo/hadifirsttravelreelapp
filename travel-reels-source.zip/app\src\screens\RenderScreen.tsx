import React from 'react';
import { Image, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import type { ImagePickerAsset } from 'expo-image-picker';
import { Button } from '../ui';
import { colors } from '../config';
import { T } from '../fonts';

const FRAMES = 6;
const TIPS = [
  'Framing each photo',
  'Adding the slow zoom',
  'Mixing in your music',
  'Placing the location title',
  'Blending the transitions',
  'Final touches',
];

function Sprockets({ width }: { width: number }) {
  const count = Math.floor(width / 13);
  return (
    <View style={{ flexDirection: 'row', gap: 7, height: 6, overflow: 'hidden' }}>
      {Array.from({ length: count }).map((_, i) => <View key={i} style={s.hole} />)}
    </View>
  );
}

export default function RenderScreen({ assets, stage, progress, error, onRetry, onBack }: {
  assets: ImagePickerAsset[]; stage: string; progress: number; error: string | null; onRetry: () => void; onBack: () => void;
}) {
  const { width } = useWindowDimensions();
  const frameW = Math.round((width - 44) * 0.27);
  const pct = Math.round(progress * 100);
  const developed = Math.min(FRAMES, Math.floor(progress * FRAMES + (progress > 0 ? 1 : 0)));
  const tip = TIPS[Math.min(TIPS.length - 1, Math.floor(progress * TIPS.length))];

  if (error) {
    return (
      <View style={s.center}>
        <Text style={[T.display, { fontSize: 32, lineHeight: 34 }]}>That didn’t work</Text>
        <Text style={[T.body, { marginTop: 10 }]}>{error}</Text>
        <View style={{ gap: 10, marginTop: 28 }}>
          <Button title="Try again" onPress={onRetry} />
          <Button title="Back to details" variant="outline" onPress={onBack} />
        </View>
      </View>
    );
  }

  return (
    <View style={s.center}>
      {/* Film strip: each frame develops into one of your photos as the reel is cut */}
      <ScrollView
        horizontal
        scrollEnabled={false}
        showsHorizontalScrollIndicator={false}
        style={{ flexGrow: 0, marginHorizontal: -22, transform: [{ rotate: '-4deg' }] }}
        contentContainerStyle={{ gap: 8, paddingHorizontal: 8, paddingVertical: 18 }}
      >
        {Array.from({ length: FRAMES }).map((_, i) => {
          const done = i < developed;
          const asset = assets[i % Math.max(1, assets.length)];
          return (
            <View key={i}>
              <Sprockets width={frameW} />
              <View style={[s.frame, { width: frameW, height: frameW * 1.4 }, done && { borderColor: colors.salt }]}>
                {done && asset ? <Image source={{ uri: asset.uri }} style={{ flex: 1, borderRadius: 8 }} /> : null}
              </View>
              <Sprockets width={frameW} />
            </View>
          );
        })}
      </ScrollView>

      <Text style={[T.display, { fontSize: 58, lineHeight: 60, marginTop: 34 }]}>{progress > 0 ? `${pct}%` : '…'}</Text>
      <Text style={[T.title, { fontSize: 28, marginTop: 4 }]}>Cutting your reel</Text>
      <Text style={[T.body, { marginTop: 8 }]}>{progress > 0 ? tip : stage}</Text>
      <View style={s.track} accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 100, now: pct }}>
        <View style={[s.fill, { width: `${Math.max(3, pct)}%` }]} />
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center' },
  hole: { width: 6, height: 6, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.55)' },
  frame: { marginVertical: 8, borderRadius: 12, borderWidth: 3, borderColor: 'rgba(255,255,255,0.28)', backgroundColor: 'rgba(10,10,14,0.4)', padding: 2 },
  track: { height: 12, borderRadius: 6, backgroundColor: 'rgba(255,255,255,0.2)', marginTop: 22, overflow: 'hidden' },
  fill: { height: '100%', backgroundColor: colors.white, borderRadius: 6 },
});
