import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';
import { File, Paths } from 'expo-file-system';
import type { ImagePickerAsset } from 'expo-image-picker';
import type { Mood } from './config';

export type Job = {
  id: string;
  status: 'queued' | 'rendering' | 'done' | 'error';
  progress: number;
  error?: string;
  duration?: number;
  music?: string | null;
  videoUrl?: string;
};

const MAX_SIDE = 1600;

/**
 * Resize to max 1600px and re-encode as JPEG. This keeps uploads small,
 * converts HEIC to JPEG and bakes in the photo's rotation.
 */
async function preparePhoto(asset: ImagePickerAsset): Promise<string> {
  const landscape = asset.width >= asset.height;
  const tooBig = Math.max(asset.width, asset.height) > MAX_SIDE;
  const ctx = ImageManipulator.manipulate(asset.uri);
  if (tooBig) ctx.resize(landscape ? { width: MAX_SIDE } : { height: MAX_SIDE });
  const image = await ctx.renderAsync();
  const saved = await image.saveAsync({ format: SaveFormat.JPEG, compress: 0.85 });
  return saved.uri;
}

const trimSlash = (url: string) => url.replace(/\/+$/, '');

export async function checkServer(serverUrl: string): Promise<boolean> {
  try {
    const controller = new AbortController();
    const t = setTimeout(() => controller.abort(), 4000);
    const r = await fetch(`${trimSlash(serverUrl)}/health`, { signal: controller.signal });
    clearTimeout(t);
    return r.ok;
  } catch {
    return false;
  }
}

export async function startRender(opts: {
  serverUrl: string;
  assets: ImagePickerAsset[];
  title: string;
  subtitle: string;
  mood: Mood;
  onStage?: (stage: string) => void;
}): Promise<Job> {
  const form = new FormData();
  for (const [i, asset] of opts.assets.entries()) {
    opts.onStage?.(`Preparing photo ${i + 1} of ${opts.assets.length}`);
    const uri = await preparePhoto(asset);
    // React Native's FormData accepts { uri, name, type } file parts.
    form.append('photos', { uri, name: `photo_${i}.jpg`, type: 'image/jpeg' } as any);
  }
  form.append('title', opts.title);
  form.append('subtitle', opts.subtitle);
  form.append('mood', opts.mood);

  opts.onStage?.('Uploading photos');
  const r = await fetch(`${trimSlash(opts.serverUrl)}/render`, { method: 'POST', body: form });
  const body = await r.json();
  if (!r.ok) throw new Error(body.error || `Server error ${r.status}`);
  return { ...body, progress: 0 } as Job;
}

export async function getJob(serverUrl: string, id: string): Promise<Job> {
  const r = await fetch(`${trimSlash(serverUrl)}/jobs/${id}`);
  const body = await r.json();
  if (!r.ok) throw new Error(body.error || `Server error ${r.status}`);
  return body as Job;
}

/** Download the finished MP4 to the app's cache and return its local URI. */
export async function downloadVideo(serverUrl: string, job: Job): Promise<string> {
  const dest = new File(Paths.cache, `reel-${job.id.slice(0, 8)}.mp4`);
  if (dest.exists) dest.delete();
  const file = await File.downloadFileAsync(`${trimSlash(serverUrl)}${job.videoUrl}`, dest);
  return file.uri;
}
