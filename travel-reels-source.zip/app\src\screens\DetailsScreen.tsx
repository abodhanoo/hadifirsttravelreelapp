import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Image, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import type { ImagePickerAsset } from 'expo-image-picker';
import { Button } from '../ui';
import { colors, Mood, MOODS } from '../config';
import { T } from '../fonts';
import { describePlace, detectPlace, deviceLocation, PlaceResult, suggestMood } from '../location';

type Props = {
  assets: ImagePickerAsset[];
  title: string; setTitle: (t: string) => void;
  subtitle: string; setSubtitle: (t: string) => void;
  mood: Mood | null; setMood: (m: Mood) => void;
  onBack: () => void;
  onCreate: () => void;
};

const SOURCE_TEXT: Record<PlaceResult['source'], string> = {
  photo: 'Found from your photo’s location',
  gallery: 'Found from your gallery',
  device: 'Photos had no location, so we used where you are now',
  none: 'No location found. Type the place name.',
};

export default function DetailsScreen(p: Props) {
  const [detecting, setDetecting] = useState(!p.title);
  const [source, setSource] = useState<PlaceResult['source'] | null>(null);

  useEffect(() => {
    if (p.title) return; // already filled (coming back from a later step)
    let alive = true;
    detectPlace(p.assets)
      .then((r) => {
        if (!alive) return;
        setSource(r.source);
        if (r.title) p.setTitle(r.title);
        if (r.subtitle) p.setSubtitle(r.subtitle);
        if (r.suggestedMood && !p.mood) p.setMood(r.suggestedMood);
      })
      .catch(() => alive && setSource('none'))
      .finally(() => alive && setDetecting(false));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const useCurrent = async () => {
    setDetecting(true);
    try {
      const c = await deviceLocation();
      if (c) {
        const place = await describePlace(c);
        if (place.title) p.setTitle(place.title);
        p.setSubtitle(place.subtitle);
        const m = suggestMood(place.raw);
        if (m) p.setMood(m);
        setSource('device');
      }
    } finally {
      setDetecting(false);
    }
  };

  const seconds = Math.min(30, Math.max(20, p.assets.length * 3));
  const thumbs = p.assets.slice(0, 4);

  return (
    <View style={{ flex: 1 }}>
      <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingBottom: 16 }}>
        <Text style={[T.title, { fontSize: 34, marginBottom: 18 }]}>Where were you?</Text>

        {/* Boarding-pass style place card */}
        <View style={s.ticket}>
          <View style={{ padding: 22, paddingBottom: 6 }}>
            <Text style={s.label}>Destination</Text>
            {detecting ? (
              <View style={s.detecting}>
                <ActivityIndicator color={colors.maroon} />
                <Text style={s.help}>Finding where these were taken…</Text>
              </View>
            ) : (
              <>
                <TextInput
                  value={p.title}
                  onChangeText={(t) => {
                    p.setTitle(t);
                    const m = suggestMood(t);
                    if (m && !p.mood) p.setMood(m);
                  }}
                  placeholder="Name this place"
                  placeholderTextColor={colors.line}
                  style={s.dest}
                  multiline
                  scrollEnabled={false}
                  maxLength={60}
                  accessibilityLabel="Location title"
                />
                <TextInput
                  value={p.subtitle}
                  onChangeText={p.setSubtitle}
                  placeholder="City, country (optional)"
                  placeholderTextColor={colors.line}
                  style={s.region}
                  maxLength={60}
                  accessibilityLabel="Region"
                />
                {source && (
                  <View style={[s.chip, source === 'none' && { backgroundColor: colors.chipMaroon }]}>
                    <Text style={[s.chipText, source === 'none' && { color: colors.chipMaroonInk }]}>{SOURCE_TEXT[source]}</Text>
                  </View>
                )}
                <Pressable onPress={useCurrent} accessibilityRole="button" style={{ paddingVertical: 12 }}>
                  <Text style={s.link}>Use my current location instead</Text>
                </Pressable>
              </>
            )}
          </View>

          {/* Perforation with notches */}
          <View style={s.perf}>
            <View style={[s.notch, { left: -15 }]} />
            <View style={s.dash} />
            <View style={[s.notch, { right: -15 }]} />
          </View>

          <View style={s.stub}>
            <View style={{ flexDirection: 'row' }}>
              {thumbs.map((a, i) => (
                <Image key={`${a.uri}-${i}`} source={{ uri: a.uri }} style={[s.thumb, i > 0 && { marginLeft: -10 }]} />
              ))}
            </View>
            <Text style={s.meta}>{p.assets.length} photos{'\n'}about {seconds} sec, vertical</Text>
          </View>
        </View>

        <Text style={[T.h3, { marginTop: 26, marginBottom: 12 }]}>Music mood</Text>
        <View style={s.moods}>
          {MOODS.map((m) => {
            const active = p.mood === m.id;
            return (
              <Pressable
                key={m.id}
                accessibilityRole="button"
                accessibilityState={{ selected: active }}
                onPress={() => p.setMood(m.id)}
                style={[s.mood, active && s.moodActive]}
              >
                <Text style={{ fontSize: 17 }}>{m.emoji}</Text>
                <Text style={[s.moodText, active && { color: colors.ink }]}>{m.label}</Text>
              </Pressable>
            );
          })}
        </View>
      </ScrollView>

      <View style={{ flexDirection: 'row', gap: 10, paddingTop: 8 }}>
        <Button title="Back" variant="soft" onPress={p.onBack} style={{ flex: 0.7 }} />
        <Button title="Create my reel" onPress={p.onCreate} disabled={!p.title.trim() || !p.mood || detecting} style={{ flex: 1.6 }} />
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  ticket: { backgroundColor: colors.salt, borderRadius: 26 },
  label: { fontFamily: 'Medium', color: colors.inkMuted, fontSize: 13.5 },
  help: { fontFamily: 'Body', color: colors.inkMuted, fontSize: 14 },
  detecting: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 22 },
  dest: { fontFamily: 'Display', color: colors.ink, fontSize: 40, lineHeight: 42, letterSpacing: -1.6, paddingHorizontal: 0, paddingVertical: 4, marginTop: 4 },
  region: { fontFamily: 'Medium', color: colors.inkSoft, fontSize: 16, paddingHorizontal: 0, paddingVertical: 4 },
  chip: { alignSelf: 'flex-start', backgroundColor: colors.chip, borderRadius: 12, paddingHorizontal: 11, paddingVertical: 7, marginTop: 10 },
  chipText: { fontFamily: 'Medium', color: colors.ink, fontSize: 13 },
  link: { fontFamily: 'Medium', color: colors.maroon, fontSize: 14.5 },
  perf: { height: 30, justifyContent: 'center' },
  dash: { marginHorizontal: 22, borderTopWidth: 2.5, borderColor: colors.line, borderStyle: 'dashed' },
  notch: { position: 'absolute', top: 0, width: 30, height: 30, borderRadius: 15, backgroundColor: colors.notch },
  stub: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 22, paddingTop: 6, paddingBottom: 20 },
  thumb: { width: 36, height: 46, borderRadius: 8, borderWidth: 2.5, borderColor: colors.salt, backgroundColor: colors.line },
  meta: { fontFamily: 'Medium', color: colors.inkSoft, fontSize: 13.5, lineHeight: 18 },
  moods: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  mood: { height: 46, borderRadius: 23, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: colors.glass },
  moodActive: { backgroundColor: colors.white },
  moodText: { fontFamily: 'Display', color: colors.white, fontSize: 15, letterSpacing: -0.2 },
});
